package com.company;

public interface setup {
    void setup();
}
