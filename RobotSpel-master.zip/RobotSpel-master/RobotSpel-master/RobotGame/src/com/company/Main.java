package com.company;

public class Main{

    public static void main(String[] args) throws InterruptedException {
        GameStart newGame = new GameStart();
        newGame.start();
    }
}