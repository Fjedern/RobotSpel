package com.company;

import java.util.Random;

public enum Direction {
    LEFT,
    RIGHT,
    UP,
    DOWN
}
