package com.company;

public class Cheetah extends Animal{

    // Full mage timer eller antal steg.

    //Konstruktor
    public Cheetah(int x, int y){
        setCurrentX(x);
        setCurrentY(y);
        setSteps(3);
        setName('C');
    }
}
